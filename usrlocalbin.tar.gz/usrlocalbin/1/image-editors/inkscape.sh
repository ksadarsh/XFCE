#!/bin/bash
sudo apt install inkscape -yy
