#!/bin/bash
sudo apt install gimp -yy
