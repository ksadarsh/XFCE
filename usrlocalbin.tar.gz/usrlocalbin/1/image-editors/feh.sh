#!/bin/bash
sudo apt install feh -yy
