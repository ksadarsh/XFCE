#!/bin/bash
sudo apt install android-sdk adb android-sdk-build-tools android-sdk-common android-sdk-platform-tools android-tools-adb android-tools-fastboot -yy
