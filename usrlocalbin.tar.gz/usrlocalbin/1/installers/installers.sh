#!/bin/bash
sudo apt install gdebi synaptic -yy
