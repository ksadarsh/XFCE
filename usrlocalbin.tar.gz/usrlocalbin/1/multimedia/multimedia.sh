#!/bin/bash
sudo apt install python-pip -yy
sudo apt install python3-pip -yy
sudo apt install handbrake -yy
sudo apt install audacity -yy
sudo apt install ubuntu-restricted-extras -yy
sudo apt install ffmpegthumbnailer -yy
sudo apt install nitrogen -yy
sudo apt install simplescreenrecorder -yy
sudo apt install parole -yy
sudo apt install transmission-gtk -yy
