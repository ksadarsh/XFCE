#!/bin/bash
sudo apt install screenfetch build-essential cmake powerline zsh -yy

sh -c "$(curl -fsSL https://raw.githubusercontent.com/robbyrussell/oh-my-zsh/master/tools/install.sh)"
